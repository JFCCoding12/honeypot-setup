
cat >honeyd.conf <<EOL
create default
set default default tcp action block
set default default udp action block
set default default icmp action block

create windows
set windows personality "Microsoft Windows XP Professional SP1"
set windows default tcp action reset
add windows tcp port 135 open
add windows tcp port 139 open
add windows tcp port 445 open
add windows tcp port 475 open

create linux
set linux personality "Linux 2.2.14"
set linux default tcp action block
set linux default udp action block
set linux default icmp action block

add linux tcp port 25 "/usr/share/honeyd/scripts/smtp.pl -n <ozooxo@gmail.com>"
add linux tcp port 8000 "/usr/share/honeyd/scripts/proxy.pl /usr/share/honeyd/scripts/smtp.pl -n <ozooxo@gmail.com>"

set windows ethernet "00:26:2d:f9:db:be"
dhcp windows on ens18

set linux ethernet "00:26:2d:f9:db:be"
dhcp linux on ens18
EOL
 
sudo honeyd -d -f honeypots.conf

