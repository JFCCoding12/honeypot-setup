# check my eth0 address
ifconfig
### eth0 Link encap:Ethernet HWaddr 00:26:2d:f9:db:be <-----------------use this one
### inet addr:192.168.0.103 Bcast:192.168.0.255 Mask:255.255.255.0
### inet6 addr: fe80::226:2dff:fef9:dbbe/64 Scope:Link
 
 
# set up the configuration file
cat >honeyd.conf <<EOL
create default
set default default tcp action block
set default default udp action block
set default default icmp action block

create windows
set windows personality "Microsoft Windows XP Professional SP1"
set windows default tcp action reset
add windows tcp port 135 open
add windows tcp port 139 open
add windows tcp port 445 open
add windows tcp port 475 open

create linux
set linux personality "Linux 2.2.14"
set linux default tcp action block
set linux default udp action block
set linux default icmp action block

add linux tcp port 25 "/usr/share/honeyd/scripts/smtp.pl -n <ozooxo@gmail.com>"
add linux tcp port 8000 "/usr/share/honeyd/scripts/proxy.pl /usr/share/honeyd/scripts/smtp.pl -n <ozooxo@gmail.com>"

set windows ethernet "00:26:2d:f9:db:be"
dhcp windows on eth0

set linux ethernet "00:26:2d:f9:db:be"
dhcp linux on eth0
EOL
 
# log in my router at http://192.168.0.1
# I get a list, in which 192.168.0.103 is me (eth0), and 192.168.0.105 is honeyd
### IP Address Name(If any) MAC
### 192.168.0.104 00:26:2d:f9:db:be
### 192.168.0.100 Landmass f0:dc:e2:a8:2b:f8
### 192.168.0.103 landmark 00:26:2d:f9:db:be
### 192.168.0.101 Landscape c8:bc:c8:5f:72:1f
### 192.168.0.102 landlubber 90:2b:34:d5:34:66
### 192.168.0.104 landmark 00:24:d7:0e:94:24
### 192.168.0.105 someone 00:26:2d:9a:83:c9
### 192.168.0.106 someone xxxxxxxxxxxxxxxxx
 
# run honeyd
sudo honeyd -d -f honeypots.conf
